module.exports = [
"[next]/internal/font/google/geist_2ae47f08.module.css [app-rsc] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "className": "geist_2ae47f08-module__h69qWW__className",
  "variable": "geist_2ae47f08-module__h69qWW__variable",
});
}),
"[next]/internal/font/google/geist_2ae47f08.js [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$geist_2ae47f08$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__ = __turbopack_context__.i("[next]/internal/font/google/geist_2ae47f08.module.css [app-rsc] (css module)");
;
const fontData = {
    className: __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$geist_2ae47f08$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].className,
    style: {
        fontFamily: "'Geist', 'Geist Fallback'",
        fontStyle: "normal"
    }
};
if (__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$geist_2ae47f08$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].variable != null) {
    fontData.variable = __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$geist_2ae47f08$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].variable;
}
const __TURBOPACK__default__export__ = fontData;
}),
"[next]/internal/font/google/geist_mono_eb58308d.module.css [app-rsc] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "className": "geist_mono_eb58308d-module__w_p2Lq__className",
  "variable": "geist_mono_eb58308d-module__w_p2Lq__variable",
});
}),
"[next]/internal/font/google/geist_mono_eb58308d.js [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$geist_mono_eb58308d$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__ = __turbopack_context__.i("[next]/internal/font/google/geist_mono_eb58308d.module.css [app-rsc] (css module)");
;
const fontData = {
    className: __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$geist_mono_eb58308d$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].className,
    style: {
        fontFamily: "'Geist Mono', 'Geist Mono Fallback'",
        fontStyle: "normal"
    }
};
if (__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$geist_mono_eb58308d$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].variable != null) {
    fontData.variable = __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$geist_mono_eb58308d$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].variable;
}
const __TURBOPACK__default__export__ = fontData;
}),
"[project]/src/app/context/page.jsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AuthContext",
    ()=>AuthContext,
    "default",
    ()=>AuthProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
(()=>{
    const e = new Error("Cannot find module '@/config'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
(()=>{
    const e = new Error("Cannot find module '@/services/authApi'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
(()=>{
    const e = new Error("Cannot find module '@/services/buttons'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
(()=>{
    const e = new Error("Cannot find module '@/services/campaign'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
(()=>{
    const e = new Error("Cannot find module '@/services/fundRequest'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
(()=>{
    const e = new Error("Cannot find module '@/services/institutes'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
(()=>{
    const e = new Error("Cannot find module '@/services/recommendedCauses'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
(()=>{
    const e = new Error("Cannot find module '@/services/uploadImg'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
(()=>{
    const e = new Error("Cannot find module 'react-router-dom'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
(()=>{
    const e = new Error("Cannot find module 'sonner'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
(()=>{
    const e = new Error("Cannot find module '@/utils/Constant'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
"";
;
;
;
;
;
;
;
;
;
;
;
;
;
const AuthContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["createContext"])(null);
function AuthProvider({ children }) {
    const [activeTab, setActiveTab] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useState"])("signin");
    const [signInFormdata, setSignInFormdata] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useState"])(initialSignInFormData);
    const [signUpFormdata, setSignUpFormdata] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useState"])(initialSignUpFormData);
    const [updateUserFormdata, setUpdateUserFormdata] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useState"])(initialUpdateFormData);
    const [activeSection, setActiveSection] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useState"])("profile");
    const [allCampaigns, setAllCampaigns] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useState"])([]);
    const [userData, setUserData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useState"])({});
    const [buttonData, setButtonData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useState"])({});
    const [inspiringInstitutesData, setInspiringInstitutesData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useState"])([]);
    const [campaignDetails, setCampaignDetails] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useState"])({});
    const [userCampaignData, setUserCampaignData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useState"])([]);
    const [recommendedCauses, setRecommendedCauses] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useState"])([]);
    const [allUserData, setAllUserData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useState"])([]);
    const [givingLevels, setGivingLevels] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useState"])([]);
    const [uploadingHero, setUploadingHero] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useState"])(false);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useState"])(false);
    const [givenAmountData, setGivenAmountData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useState"])([]);
    const navigator = useNavigate();
    // change signup form data
    function handleChangeSignUpFormdata(e) {
        const { name, value } = e.target;
        setSignUpFormdata({
            ...signUpFormdata,
            [name]: value
        });
    }
    // change signin form data
    function handleChangeSignInFormdata(e) {
        const { name, value } = e.target;
        setSignInFormdata({
            ...signInFormdata,
            [name]: value
        });
    }
    // change update user data
    async function handleChangeUpdateUserFormdata(e) {
        const { name, value, files } = e.target;
        if (files && files.length > 0) {
            const file = files[0];
            try {
                setUploadingHero(true);
                const uploadedUrl = await uploadFile(file);
                console.log("Uploaded Image URL:", uploadedUrl);
                setUpdateUserFormdata((prev)=>{
                    const updated = {
                        ...prev,
                        [name]: uploadedUrl
                    };
                    console.log("New Form Data:", updated);
                    return updated;
                });
            } catch (error) {
                console.error("File upload failed:", error);
            } finally{
                setUploadingHero(false);
            }
        } else {
            setUpdateUserFormdata((prev)=>({
                    ...prev,
                    [name]: value
                }));
        }
    }
    //   check if signup form is valid
    function checkIfSignUpFormIsValid() {
        const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
        return signUpFormdata && signUpFormdata.fullName !== "" && signUpFormdata.userEmail !== "" && signUpFormdata.password !== "" && passwordRegex.test(signUpFormdata.password);
    }
    //   check if signin form is valid
    function checkIfSignInFormIsValid() {
        return signInFormdata && signInFormdata.email !== "" && signInFormdata.password !== "";
    }
    //   sumbit register form
    const registerHandleSubmit = async (e)=>{
        e.preventDefault();
        try {
            const result = await registerService(signUpFormdata);
            console.log(result);
            if (result?.success) {
                toast.success("Registered successfully!");
                setActiveTab("signin"); // ✅ change tab after successful registration
            } else {
                toast.error(result.message || "Registration failed");
            }
        } catch (error) {
            // ✅ This handles unexpected server errors or non-JSON responses
            const message = error?.response?.data?.message || error.message || "Something went wrong";
            toast.error(message);
        }
    };
    // login form
    const loginHandleSubmit = async (e)=>{
        e.preventDefault();
        const result = await loginUser(signInFormdata);
        try {
            if (result?.success) {
                toast.success("Login successfully!");
                localStorage.setItem("id", result.data.user._id);
                navigator("/dashboard");
                setActiveSection("profile");
                window.location.reload();
            } else {
                toast.error(result.message || "Login failed");
            }
        } catch (error) {
            const message = error?.response?.data?.message || error.message || "Something went wrong";
            toast.error(message);
        }
    };
    // update user
    async function getUserData() {
        const userData = await getAuthenticatedUser();
        if (userData) setUserData(userData);
    }
    const updateHandleUser = async (e)=>{
        e.preventDefault();
        const id = localStorage.getItem("id");
        const result = await updateUser(updateUserFormdata);
        if (result?.success) {
            toast.success("User updated successfully!");
            // console.log(resultdata);
            setActiveSection("dashboard");
            getUserData();
        } else {
            toast.error(result?.message || "User update failed");
            console.log(result);
        }
    };
    // get user Campaign
    async function getSingleCampaignsData() {
        const loignInstitutesData = await getAllCampaigns();
        if (loignInstitutesData) setUserCampaignData(loignInstitutesData.data);
    }
    // get all Copmaign
    async function getAllCampaignsData() {
        setLoading(true);
        const compaignData = await getAllCampaigns();
        if (compaignData) setAllCampaigns(compaignData.data);
        setLoading(false);
    }
    // get buttons data
    async function getButtonsData() {
        const data = await getButtons();
        if (data) setButtonData(data);
    }
    // get all inspiring institutes
    async function getAllInspiringInstitutesData() {
        const institutesData = await getAllInspiringInstitutes();
        if (institutesData) setInspiringInstitutesData(institutesData.data);
    }
    // get all recommended causes
    async function getRecommendedCausesData() {
        const RecommendedCauses = await getAllRecommendedCauses();
        if (RecommendedCauses) setRecommendedCauses(RecommendedCauses.data);
    }
    // get all user
    async function getLoginUserData() {
        const getAllUserData = await getData();
        if (getAllUserData) setAllUserData(getAllUserData.data);
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        getUserData();
        getSingleCampaignsData();
        getAllCampaignsData();
        getButtonsData();
        getAllInspiringInstitutesData();
        getRecommendedCausesData();
        getLoginUserData();
    }, []);
    const [formData, setFormData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useState"])(()=>{
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        return {};
    });
    const navigate = useNavigate();
    const createCampaign = async (e)=>{
        const result = await campaign(formData);
        if (result?.success) {
            localStorage.removeItem("campaignData");
            navigate("/dashboard");
            setActiveSection("fundraisers");
            getSingleCampaignsData();
            toast.success("Campaign created successfully!");
        } else {
            toast.error(result?.message || "Campaign creation failed");
        }
    };
    // console.log(allUserData);
    const handleCreateComment = async (formData, id)=>{
        const data = await createComment(formData, id);
        if (data?.success) {
            console.log("Comment created successfully:", data);
            toast.success("Thanks for your comment!");
            return data; // return campaign data
        } else {
            console.warn(data);
            return data.err;
        }
    // payment 
    };
    //  console.log(updateUserFormdata);
    // fund request 
    const handleSubmitFundRequest = async (e)=>{
        e.preventDefault();
        const data = new FormData(e.target);
        const formData = Object.fromEntries(data);
        console.log(formData);
        const result = await createFundRequest(formData);
        if (result?.success) {
            toast.success("Fund request created successfully!");
        } else {
            toast.error(result?.message || "Fund request creation failed");
        }
        try {
            const data = await fetch(`${baseUrl}/v1/api/sendMail/send-fund-request-mail`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    campaignName: `give me money`,
                    email: `razaira01@gmail.com`
                })
            }).then((res)=>{
                if (res.ok) {
                    console.log("Email sent successfully");
                }
                toast.success("Message sent successfully");
            });
        } catch (error) {
            console.log(error);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(AuthContext.Provider, {
        value: {
            signInFormdata,
            setSignInFormdata,
            signUpFormdata,
            setSignUpFormdata,
            handleChangeSignUpFormdata,
            handleChangeSignInFormdata,
            checkIfSignUpFormIsValid,
            checkIfSignInFormIsValid,
            registerHandleSubmit,
            loginHandleSubmit,
            setUserData,
            Toaster,
            toast,
            userData,
            activeTab,
            setActiveTab,
            formData,
            setFormData,
            createCampaign,
            allCampaigns,
            updateUserFormdata,
            setUpdateUserFormdata,
            handleChangeUpdateUserFormdata,
            updateHandleUser,
            setActiveSection,
            activeSection,
            buttonData,
            inspiringInstitutesData,
            campaignDetails,
            setCampaignDetails,
            userCampaignData,
            recommendedCauses,
            allUserData,
            handleCreateComment,
            givingLevels,
            setGivingLevels,
            loading,
            givenAmountData,
            setGivenAmountData,
            uploadingHero,
            setUploadingHero,
            handleSubmitFundRequest
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/src/app/context/page.jsx",
        lineNumber: 403,
        columnNumber: 5
    }, this);
}
}),
"[project]/src/app/layout.js [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>RootLayout,
    "metadata",
    ()=>metadata
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$geist_2ae47f08$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[next]/internal/font/google/geist_2ae47f08.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$geist_mono_eb58308d$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[next]/internal/font/google/geist_mono_eb58308d.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$context$2f$page$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/context/page.jsx [app-rsc] (ecmascript)");
;
;
;
;
;
const metadata = {
    title: "Create Next App",
    description: "Generated by create next app"
};
function RootLayout({ children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("html", {
        lang: "en",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("body", {
            className: `${__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$geist_2ae47f08$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"].variable} ${__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$geist_mono_eb58308d$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"].variable} antialiased`,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$context$2f$page$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                children: children
            }, void 0, false, {
                fileName: "[project]/src/app/layout.js",
                lineNumber: 26,
                columnNumber: 7
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/layout.js",
            lineNumber: 23,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/layout.js",
        lineNumber: 22,
        columnNumber: 5
    }, this);
}
}),
"[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/server/route-modules/app-page/module.compiled.js [app-rsc] (ecmascript)").vendored['react-rsc'].ReactJsxDevRuntime; //# sourceMappingURL=react-jsx-dev-runtime.js.map
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__7d684da3._.js.map