module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[project]/src/app/utils/Constant.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// export const baseUrl = "https://wedding-backend-1-7klv.onrender.com";
__turbopack_context__.s([
    "baseUrl",
    ()=>baseUrl
]);
const baseUrl = "http://localhost:4000";
}),
"[project]/src/app/services/authApi.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getAuthenticatedUser",
    ()=>getAuthenticatedUser,
    "getData",
    ()=>getData,
    "loginUser",
    ()=>loginUser,
    "registerService",
    ()=>registerService,
    "updateUser",
    ()=>updateUser
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$utils$2f$Constant$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/utils/Constant.js [app-ssr] (ecmascript)");
;
async function registerService(formData) {
    try {
        const res = await fetch(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$utils$2f$Constant$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["baseUrl"]}/auth/register`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(formData)
        });
        const data = await res.json();
        return data;
    } catch (err) {
        console.error("Register error:", err);
        return err;
    }
}
async function loginUser(formData) {
    try {
        const res = await fetch(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$utils$2f$Constant$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["baseUrl"]}/auth/login`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(formData)
        });
        const data = await res.json();
        // console.log("login user dara:", data.user);
        if (data?.data?.token) {
            localStorage.setItem("token", data.data.token);
        }
        return data;
    } catch (err) {
        console.error("Login Error:", err);
        return err;
    }
}
async function getAuthenticatedUser() {
    try {
        if (!token) {
            console.warn("No token found in localStorage");
            return null;
        }
        const res = await fetch(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$utils$2f$Constant$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["baseUrl"]}/auth/check-auth`, {
            method: "GET",
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        const data = await res.json();
        if (data.success) {
            // console.log("Authenticated user:", data.data);
            return data.data // return user data
            ;
        } else {
            console.warn("Authentication failed");
            return null;
        }
    } catch (error) {
        console.error("Error checking auth:", error);
        return null;
    }
}
async function updateUser(formData) {
    try {
        const res = await fetch(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$utils$2f$Constant$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["baseUrl"]}/auth/update-user`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${token}`
            },
            body: JSON.stringify(formData)
        });
        const data = await res.json();
        if (data.success) {
            console.log("User updated successfully:", data.data.user);
            return data; // return user data
        } else {
            console.log("User update failed");
            return data.err;
        }
    } catch (error) {
        console.log(error);
    }
}
async function getData() {
    try {
        const response = await fetch(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$utils$2f$Constant$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["baseUrl"]}/auth/get-user-data`);
        const data = await response.json();
        return data;
    } catch (err) {
        console.log(err);
    }
}
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[project]/src/app/services/blog.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createBlog",
    ()=>createBlog,
    "deleteBlog",
    ()=>deleteBlog,
    "getBlog",
    ()=>getBlog,
    "updateBlog",
    ()=>updateBlog
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$utils$2f$Constant$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/utils/Constant.js [app-ssr] (ecmascript)");
;
const getBlog = async ()=>{
    try {
        const data = await fetch(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$utils$2f$Constant$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["baseUrl"]}/v1/api/get-blog`);
        const res = await data.json();
        return res;
    } catch (error) {
        return error;
    }
};
const createBlog = async (formData)=>{
    try {
        const data = await fetch(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$utils$2f$Constant$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["baseUrl"]}/v1/api/create-blog`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(formData)
        });
        const res = await data.json();
        return res;
    } catch (error) {
        return error;
    }
};
const deleteBlog = async (id)=>{
    try {
        const data = await fetch(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$utils$2f$Constant$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["baseUrl"]}/v1/api/delete-blog/${id}`, {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json"
            }
        });
        const res = await data.json();
        return res;
    } catch (error) {
        return error;
    }
};
const updateBlog = async (id, formData)=>{
    try {
        const data = await fetch(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$utils$2f$Constant$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["baseUrl"]}/v1/api/update-blog/${id}`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(formData)
        });
        const res = await data.json();
        return res;
    } catch (error) {
        return error;
    }
};
}),
"[project]/src/app/context/page.jsx [app-ssr] (ecmascript)", ((__turbopack_context__, module, exports) => {

const e = new Error("Could not parse module '[project]/src/app/context/page.jsx'\n\nExpected '}', got '<eof>'");
e.code = 'MODULE_UNPARSABLE';
throw e;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/dynamic-access-async-storage.external.js [external] (next/dist/server/app-render/dynamic-access-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/dynamic-access-async-storage.external.js", () => require("next/dist/server/app-render/dynamic-access-async-storage.external.js"));

module.exports = mod;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__b3f8cf63._.js.map